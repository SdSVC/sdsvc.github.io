 
 This is a Kaldi recipe for speaker verification baseline for task1 and task2 
 of Short-duration Speaker Verification Challenge 2020.  It is using the VoxCeleb1 and
 VoxCeleb2 corpora for training.  See http://www.robots.ox.ac.uk/~vgg/data/voxceleb/ and 
 http://www.robots.ox.ac.uk/~vgg/data/voxceleb2/ for additional details and
 information on how to obtain them.

 Note: This recipe requires ffmpeg to be installed and its location included
 in $PATH

