#!/bin/bash

train_cmd=
extract_cmd=
stage=0
train_stage=-1
nnet_dir=exp/xvector_nnet_jhu

. ./cmd.sh
. ./path.sh
set -e
. ./utils/parse_options.sh

mfccdir=/mnt/scratch03/tmp/zeinali/sdsvc2020/mfcc
vaddir=/mnt/scratch03/tmp/zeinali/sdsvc2020/vad

voxceleb1_root=/mnt/matylda2/data/voxceleb_1.1
voxceleb2_root=/mnt/matylda2/data/voxceleb2
musan_root=/mnt/matylda2/data/MUSAN/musan

if [[ ${stage} -le 0 ]]; then

  local/make_voxceleb1.pl ${voxceleb1_root} data/voxceleb1

  local/make_voxceleb2.pl ${voxceleb2_root} test data/voxceleb2_test
  local/make_voxceleb2.pl ${voxceleb2_root} dev data/voxceleb2_train

  local/make_sdsvc_eval.py --task task1 --data-dir data \
    --task-root-dir /mnt/matylda6/zeinali/DeepMine/Challenge/task1 \
	--check-file-exist yes

  local/make_sdsvc_eval.py --task task2 --data-dir data \
    --task-root-dir /mnt/matylda6/zeinali/DeepMine/Challenge/task2 \
	--check-file-exist yes

  utils/combine_data.sh data/train data/voxceleb2_train data/voxceleb2_test \
    data/voxceleb1

fi

if [[ ${stage} -le 1 ]]; then

  # Make MFCCs and compute the energy-based VAD for each dataset
  for name in train sdsv_challenge_task1.enroll sdsv_challenge_task1.test \
    sdsv_challenge_task2.enroll sdsv_challenge_task2.test; do
    steps/make_mfcc.sh --write-utt2num-frames true --mfcc-config conf/mfcc.conf --nj 40 \
      --cmd "${extract_cmd}" data/${name} exp/make_mfcc ${mfccdir}
    utils/fix_data_dir.sh data/${name}
    sid/compute_vad_decision.sh --nj 40 --cmd "${extract_cmd}" \
      data/${name} exp/make_vad ${vaddir}
    utils/fix_data_dir.sh data/${name}
  done
  
fi

# In this section, we augment the train data with reverberation,
# noise, music, and babble, and combine it with the clean data.
if [[ ${stage} -le 2 ]]; then

  frame_shift=0.01
  awk -v frame_shift=${frame_shift} '{print $1, $2*frame_shift;}' data/train/utt2num_frames > data/train/reco2dur

  if [[ ! -d "RIRS_NOISES" ]]; then
    # Download the package that includes the real RIRs, simulated RIRs, isotropic noises and point-source noises
    wget --no-check-certificate http://www.openslr.org/resources/28/rirs_noises.zip
    unzip rirs_noises.zip
  fi

  if [[ ! -d "data/musan" ]]; then
    # Prepare the MUSAN corpus, which consists of music, speech, and noise
    # suitable for augmentation.
    steps/data/make_musan.sh --sampling-rate 16000 ${musan_root} data

    # Get the duration of the MUSAN recordings.  This will be used by the
    # script augment_data_dir.py.
    for name in speech noise music; do
      utils/data/get_utt2dur.sh data/musan_${name}
      mv data/musan_${name}/utt2dur data/musan_${name}/reco2dur
    done
  fi

  # Make a version with reverberated speech
  rvb_opts=()
  rvb_opts+=(--rir-set-parameters "0.5, RIRS_NOISES/simulated_rirs/smallroom/rir_list")
  rvb_opts+=(--rir-set-parameters "0.5, RIRS_NOISES/simulated_rirs/mediumroom/rir_list")

  # Make a reverberated version of the VoxCeleb2 list.  Note that we don't add any
  # additive noise here.
  steps/data/reverberate_data_dir.py \
    "${rvb_opts[@]}" \
    --speech-rvb-probability 1 \
    --pointsource-noise-addition-probability 0 \
    --isotropic-noise-addition-probability 0 \
    --num-replications 1 \
    --source-sampling-rate 16000 \
    data/train data/train_reverb
  cp data/train/vad.scp data/train_reverb/
  utils/copy_data_dir.sh --utt-suffix "-reverb" data/train_reverb data/train_reverb.new
  rm -rf data/train_reverb
  mv data/train_reverb.new data/train_reverb

  # Augment with musan_noise
  steps/data/augment_data_dir.py --utt-suffix "noise" --fg-interval 1 --fg-snrs "15:10:5:0" \
    --fg-noise-dir "data/musan_noise" data/train data/train_noise
  # Augment with musan_music
  steps/data/augment_data_dir.py --utt-suffix "music" --bg-snrs "15:10:8:5" --num-bg-noises "1" \
    --bg-noise-dir "data/musan_music" data/train data/train_music
  # Augment with musan_speech
  steps/data/augment_data_dir.py --utt-suffix "babble" --bg-snrs "20:17:15:13" --num-bg-noises "3:4:5:6:7" \
    --bg-noise-dir "data/musan_speech" data/train data/train_babble

  # Combine reverb, noise, music, and babble into one directory.
  utils/combine_data.sh data/train_aug data/train_reverb data/train_noise data/train_music data/train_babble

  # Take a random subset of the augmentations
  utils/subset_data_dir.sh data/train_aug 2000000 data/train_aug_2m
  utils/fix_data_dir.sh data/train_aug_2m

  # Make MFCCs for the augmented data.  Note that we do not compute a new
  # vad.scp file here.  Instead, we use the vad.scp from the clean version of
  # the list.
  steps/make_mfcc.sh --mfcc-config conf/mfcc.conf --nj 2000 --cmd "${extract_cmd} --max-jobs-run 100" \
    data/train_aug_2m exp/make_mfcc ${mfccdir}

  # Combine the clean and augmented VoxCeleb2 list.  This is now roughly
  # double the size of the original clean list.
  utils/combine_data.sh data/train_combined data/train_aug_2m data/train

fi

# Now we prepare the features to generate examples for xvector training.
if [[ ${stage} -le 3 ]]; then

  # This script applies CMVN and removes nonspeech frames.  Note that this is somewhat
  # wasteful, as it roughly doubles the amount of training data on disk.  After
  # creating training examples, this can be removed.
  local/nnet3/xvector/prepare_feats_for_egs.sh --nj 40 --cmd "${extract_cmd}" \
    data/train_combined data/train_combined_no_sil /mnt/scratch03/tmp/zeinali/sdsvc2020/exp/train_combined_no_sil
  utils/fix_data_dir.sh data/train_combined_no_sil

  # Now, we need to remove features that are too short after removing silence
  # frames.  We want at least 2.1s (210 frames) per utterance.
  min_len=210
  mv data/train_combined_no_sil/utt2num_frames data/train_combined_no_sil/utt2num_frames.bak
  awk -v min_len=${min_len} '$2 > min_len {print $1, $2}' data/train_combined_no_sil/utt2num_frames.bak > data/train_combined_no_sil/utt2num_frames
  utils/filter_scp.pl data/train_combined_no_sil/utt2num_frames data/train_combined_no_sil/utt2spk > data/train_combined_no_sil/utt2spk.new
  mv data/train_combined_no_sil/utt2spk.new data/train_combined_no_sil/utt2spk
  utils/fix_data_dir.sh data/train_combined_no_sil

  # We also want several utterances per speaker. Now we'll throw out speakers
  # with fewer than 8 utterances.
  min_num_utts=8
  awk '{print $1, NF-1}' data/train_combined_no_sil/spk2utt > data/train_combined_no_sil/spk2num
  awk -v min_num_utts=${min_num_utts} '$2 >= min_num_utts {print $1, $2}' data/train_combined_no_sil/spk2num | utils/filter_scp.pl - data/train_combined_no_sil/spk2utt > data/train_combined_no_sil/spk2utt.new
  mv data/train_combined_no_sil/spk2utt.new data/train_combined_no_sil/spk2utt
  utils/spk2utt_to_utt2spk.pl data/train_combined_no_sil/spk2utt > data/train_combined_no_sil/utt2spk

  utils/filter_scp.pl data/train_combined_no_sil/utt2spk data/train_combined_no_sil/utt2num_frames > data/train_combined_no_sil/utt2num_frames.new
  mv data/train_combined_no_sil/utt2num_frames.new data/train_combined_no_sil/utt2num_frames

  # Now we're ready to create training examples.
  utils/fix_data_dir.sh data/train_combined_no_sil

fi

# Stages 4 through 6 are handled in run_xvector.sh
local/nnet3/xvector/run_xvector.sh --stage ${stage} --train-stage ${train_stage} \
  --data data/train_combined_no_sil --nnet-dir ${nnet_dir} \
  --egs-dir /mnt/scratch02/tmp/zeinali/sdsvc2020/orig_200/egs

if [[ ${stage} -le 7 ]]; then

  # Extract x-vectors for centering, LDA, and PLDA training.
  sid/nnet3/xvector/extract_xvectors.sh --cmd "${train_cmd} --mem 4G --max-jobs-run 200" --nj 2000 \
    ${nnet_dir} data/train ${nnet_dir}/xvectors_train

  # Extract x-vectors used in the evaluation.
  for name in sdsv_challenge_task1.enroll sdsv_challenge_task1.test \
    sdsv_challenge_task2.enroll sdsv_challenge_task2.test; do
    sid/nnet3/xvector/extract_xvectors.sh --cmd "${train_cmd} --mem 4G --max-jobs-run 200" --nj 1000 \
      ${nnet_dir} data/${name} ${nnet_dir}/xvectors_${name}
  done

fi

if [[ ${stage} -le 8 ]]; then

  # Compute the mean vector for centering the evaluation xvectors.
  ${train_cmd} ${nnet_dir}/xvectors_train/log/compute_mean.log \
    ivector-mean scp:${nnet_dir}/xvectors_train/xvector.scp \
    ${nnet_dir}/xvectors_train/mean.vec || exit 1;

  # This script uses LDA to decrease the dimensionality prior to PLDA.
  lda_dim=200
  ${train_cmd} ${nnet_dir}/xvectors_train/log/lda.log \
    ivector-compute-lda --total-covariance-factor=0.0 --dim=${lda_dim} \
    "ark:ivector-subtract-global-mean scp:${nnet_dir}/xvectors_train/xvector.scp ark:- |" \
    ark:data/train/utt2spk ${nnet_dir}/xvectors_train/transform.mat || exit 1;

  # Train the PLDA model.
  ${train_cmd} ${nnet_dir}/xvectors_train/log/plda.log \
    ivector-compute-plda ark:data/train/spk2utt \
    "ark:ivector-subtract-global-mean scp:${nnet_dir}/xvectors_train/xvector.scp ark:- | transform-vec ${nnet_dir}/xvectors_train/transform.mat ark:- ark:- | ivector-normalize-length ark:-  ark:- |" \
    ${nnet_dir}/xvectors_train/plda || exit 1;

fi

if [[ ${stage} -le 9 ]]; then

  for name in sdsv_challenge_task1 sdsv_challenge_task2; do
    ${train_cmd} ${nnet_dir}/scores/log/${name}_scoring.log \
      ivector-plda-scoring --normalize-length=true \
      --num-utts=ark:${nnet_dir}/xvectors_${name}.enroll/num_utts.ark \
      "ivector-copy-plda --smoothing=0.0 ${nnet_dir}/xvectors_train/plda - |" \
      "ark:ivector-mean ark:data/${name}.enroll/spk2utt scp:${nnet_dir}/xvectors_${name}.enroll/xvector.scp ark:- | ivector-subtract-global-mean ${nnet_dir}/xvectors_train/mean.vec ark:- ark:- | transform-vec ${nnet_dir}/xvectors_train/transform.mat ark:- ark:- | ivector-normalize-length ark:- ark:- |" \
      "ark:ivector-subtract-global-mean ${nnet_dir}/xvectors_train/mean.vec scp:${nnet_dir}/xvectors_${name}.test/xvector.scp ark:- | transform-vec ${nnet_dir}/xvectors_train/transform.mat ark:- ark:- | ivector-normalize-length ark:- ark:- |" \
      "cat 'data/${name}.test/trials' | cut -d\  --fields=1,2 |" ${nnet_dir}/scores/${name}_scores || exit 1;
  done

fi
