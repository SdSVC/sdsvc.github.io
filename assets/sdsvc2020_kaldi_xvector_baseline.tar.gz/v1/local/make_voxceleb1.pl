#!/usr/bin/perl
#
# Usage: make_voxceleb1.pl /export/voxceleb1 data/voxceleb1
#

if (@ARGV != 2) {
  print STDERR "Usage: $0 <path-to-voxceleb1> <path-to-data-dir>\n";
  print STDERR "e.g. $0 /export/voxceleb1 data/voxceleb1\n";
  exit(1);
}

($data_base, $out_dir) = @ARGV;

if (system("mkdir -p $out_dir") != 0) {
  die "Error making directory $out_dir";
}

opendir my $dh, "$data_base/wav" or die "Cannot open directory: $!";
my @spkr_dirs = grep {-d "$data_base/wav/$_" && ! /^\.{1,2}$/} readdir($dh);
closedir $dh;

open(SPKR_TRAIN, ">", "$out_dir/utt2spk") or die "could not open the output file $out_dir/utt2spk";
open(WAV_TRAIN, ">", "$out_dir/wav.scp") or die "could not open the output file $out_dir/wav.scp";

foreach (@spkr_dirs) {
  my $spkr_id = $_;
  opendir my $dh, "$data_base/wav/$spkr_id/" or die "Cannot open directory: $!";
  my @rec_dirs = grep {-d "$data_base/wav/$spkr_id/$_" && ! /^\.{1,2}$/} readdir($dh);
  closedir $dh;
  foreach (@rec_dirs) {
    my $rec_id = $_;
    opendir my $dh, "$data_base/wav/$spkr_id/$rec_id/" or die "Cannot open directory: $!";
    my @files = map{s/\.[^.]+$//;$_}grep {/\.wav$/} readdir($dh);
    closedir $dh;
    foreach (@files) {
      my $name = $_;
      my $wav = "$data_base/wav/$spkr_id/$rec_id/$name.wav";
      my $utt_id = "$spkr_id-$rec_id-$name";
      print WAV_TRAIN "$utt_id", " $wav", "\n";
      print SPKR_TRAIN "$utt_id", " $spkr_id", "\n";
    }
  }
}
close(SPKR_TRAIN) or die;
close(WAV_TRAIN) or die;

if (system(
  "utils/utt2spk_to_spk2utt.pl $out_dir/utt2spk >$out_dir/spk2utt") != 0) {
  die "Error creating spk2utt file in directory $out_dir";
}
system("env LC_COLLATE=C utils/fix_data_dir.sh $out_dir");
if (system("env LC_COLLATE=C utils/validate_data_dir.sh --no-text --no-feats $out_dir") != 0) {
  die "Error validating directory $out_dir";
}
